package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
   private static Connection conn;
public static Connection getConnection() {
    if (conn == null) {
        try {
            String url = PropertyUtil.getPropertyString("db.url");
            String username = PropertyUtil.getPropertyString("db.username");
            String password = PropertyUtil.getPropertyString("db.password");
            conn = DriverManager.getConnection(url, username, password);
        } catch (SQLException var1) {
            var1.printStackTrace();
        }
    }
    return conn;
   }
}
