package util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertyUtil {
public static String getPropertyString(String propertyName) {
    Properties properties = new Properties();
    try (FileInputStream fis = new FileInputStream("src/database.properties")) {
        properties.load(fis);
        return properties.getProperty(propertyName);
    } catch (IOException e) {
        e.printStackTrace();
        return null;
    }
}
}
