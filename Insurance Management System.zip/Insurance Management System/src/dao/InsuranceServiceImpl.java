package dao;

import entity.Policy;
import exception.PolicyNotFoundException;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

public class InsuranceServiceImpl implements IPolicyService {
    private Connection conn = DBConnection.getConnection();

    @Override
    public boolean createPolicy(Policy policy) {
        try {
            String query = "INSERT INTO Policy (policyId, policyName) VALUES (?, ?)";
            PreparedStatement stmt = this.conn.prepareStatement(query);
            stmt.setInt(1, policy.getPolicyId());
            stmt.setString(2, policy.getPolicyName());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException exception) {
            exception.printStackTrace();
            return false;
        }
    }

    @Override
    public Policy getPolicy(int policyId) {
        try {
            String query = "SELECT * FROM Policy WHERE policyId = ?";
            PreparedStatement stmt = this.conn.prepareStatement(query);
            stmt.setInt(1, policyId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Policy policy = new Policy();
                policy.setPolicyId(rs.getInt("policyId"));
                policy.setPolicyName(rs.getString("policyName"));
                return policy;
            } else {
                throw new PolicyNotFoundException("Policy not found.");
            }
        } catch (SQLException | PolicyNotFoundException exception) {
            exception.printStackTrace();
        }
        return null;
    }

    @Override
    public Collection<Policy> getAllPolicies() {
        Collection<Policy> policies = new ArrayList<>();
        try {
            String query = "SELECT * FROM Policy";
            PreparedStatement stmt = this.conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while(rs.next()) {
                Policy policy = new Policy();
                policy.setPolicyId(rs.getInt("policyId"));
                policy.setPolicyName(rs.getString("policyName"));
                policies.add(policy);
            }
        } catch (SQLException exception) {
            exception.printStackTrace();
        }
        return policies;
    }

    @Override
    public boolean updatePolicy(Policy policy) {
        try {
            String query = "UPDATE Policy SET policyName = ? WHERE policyId = ?";
            PreparedStatement stmt = this.conn.prepareStatement(query);
            stmt.setString(1, policy.getPolicyName());
            stmt.setInt(2, policy.getPolicyId());
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException exception) {
            exception.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deletePolicy(int policyId) {
        try {
            String query = "DELETE FROM Policy WHERE policyId = ?";
            PreparedStatement stmt = this.conn.prepareStatement(query);
            stmt.setInt(1, policyId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException exception) {
            exception.printStackTrace();
            return false;
        }
    }
}
